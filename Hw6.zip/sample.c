#include<stdio.h>

int main()
{
    FILE *fp;
    char buf[100];
    fp = fopen("pikachu.txt","r");
    while(fgets(buf, 100, fp) != NULL)
    {
        printf("%s",buf);
    }
    fclose(fp);
    return 0;
}

